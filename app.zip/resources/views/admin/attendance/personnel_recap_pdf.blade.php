<!DOCTYPE html>
<html>
<head>
    <title>Rekap Kehadiran Pegawai</title>
    <style>
        @page { margin: 20px; }
        body { font-family: sans-serif; font-size: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 2px; text-align: center; font-size: 9px; }
        th.name-col, td.name-col { text-align: left; min-width: 150px; padding-left: 5px; }
        .holiday { background-color: #ffcccc; color: #cc0000; }
        .H { color: green; font-weight: bold; }
        .S { color: #d9a400; font-weight: bold; }
        .I { color: blue; font-weight: bold; }
        .A { color: red; font-weight: bold; }
        h2, h3 { text-align: center; margin: 5px 0; }
    </style>
</head>
<body>
    <h2>REKAP KEHADIRAN PEGAWAI</h2>
    <h3>Bulan: {{ date('F', mktime(0, 0, 0, $month, 1)) }} {{ $year }}</h3>
    <table>
        <thead>
            <tr>
                <th rowspan="2" class="name-col">NAMA / NIP</th>
                @for($i = 1; $i <= $daysInMonth; $i++)
                    @php
                        $date = $startDate->copy()->day($i);
                        $isSunday = $date->isSunday();
                    @endphp
                    <th class="{{ $isSunday ? 'holiday' : '' }}">{{ sprintf('%02d', $i) }}</th>
                @endfor
            </tr>
            <tr>
                @for($i = 1; $i <= $daysInMonth; $i++)
                    @php
                        $date = $startDate->copy()->day($i);
                        $isSunday = $date->isSunday();
                    @endphp
                    <th class="{{ $isSunday ? 'holiday' : '' }}">{{ strtoupper(substr($date->shortEnglishDayOfWeek, 0, 2)) }}</th>
                @endfor
            </tr>
        </thead>
        <tbody>
            @foreach($personnel as $person)
                <tr>
                    <td class="name-col">
                        <b>{{ $person->name }}</b><br>
                        <span style="font-size: 8px;">{{ $person->teacher->nip ?? 'A000000000001' }}</span>
                    </td>
                    @for($i = 1; $i <= $daysInMonth; $i++)
                        @php
                            $date = $startDate->copy()->day($i);
                            $isSunday = $date->isSunday();
                            $attendance = isset($attendanceData[$person->id][$i]) ? $attendanceData[$person->id][$i]->first(function($a) use ($date) {
                                $dateString = $date->toDateString();
                                return $a->date instanceof \Carbon\Carbon 
                                    ? $a->date->toDateString() == $dateString 
                                    : (string)$a->date == $dateString;
                            }) : null;
                            
                            $statusChar = '';
                            $cellClass = '';
                            
                            if ($isSunday) {
                                $statusChar = 'L';
                                $cellClass = 'holiday';
                            } elseif ($attendance) {
                                switch($attendance->status) {
                                    case 'present': $statusChar = 'H'; $cellClass = 'H'; break;
                                    case 'sick': $statusChar = 'S'; $cellClass = 'S'; break;
                                    case 'permission': $statusChar = 'I'; $cellClass = 'I'; break;
                                    case 'absent': $statusChar = 'A'; $cellClass = 'A'; break;
                                }
                            }
                        @endphp
                        <td class="{{ $cellClass }}">
                            {{ $statusChar }}
                        </td>
                    @endfor
                </tr>
            @endforeach
        </tbody>
    </table>

    <div style="margin-top: 20px;">
        <h3>KETERANGAN / CATATAN</h3>
        <table style="width: 100%;">
            <thead>
                <tr>
                    <th style="width: 20%;">Tanggal</th>
                    <th style="width: 25%;">Nama Pegawai</th>
                    <th style="width: 15%;">Status</th>
                    <th style="width: 40%;">Keterangan</th>
                </tr>
            </thead>
            <tbody>
                @php $hasDescription = false; @endphp
                @foreach($personnel as $person)
                    @for($i = 1; $i <= $daysInMonth; $i++)
                        @php
                            $attendance = isset($attendanceData[$person->id][$i]) ? $attendanceData[$person->id][$i]->first() : null;
                        @endphp
                        @if($attendance && $attendance->description)
                            @php $hasDescription = true; @endphp
                            <tr>
                                <td>{{ Carbon\Carbon::parse($attendance->date)->format('d M Y') }}</td>
                                <td style="text-align: left; padding-left: 5px;">{{ $person->name }}</td>
                                <td>
                                    @switch($attendance->status)
                                        @case('present') Hadir @break
                                        @case('sick') Sakit @break
                                        @case('permission') Izin @break
                                        @case('absent') Alfa @break
                                    @endswitch
                                </td>
                                <td style="text-align: left; padding-left: 5px;">{{ $attendance->description }}</td>
                            </tr>
                        @endif
                    @endfor
                @endforeach
                @if(!$hasDescription)
                    <tr>
                        <td colspan="4" style="padding: 10px; color: #666;">Tidak ada keterangan tambahan.</td>
                    </tr>
                @endif
            </tbody>
        </table>
    <div style="margin-top: 40px; width: 100%;">
        <table style="border: none; width: 100%;">
            <tr>
                <td style="border: none; width: 60%;"></td>
                <td style="border: none; width: 40%; text-align: center; font-size: 11px;">
                    <p>Makassar, {{ Carbon\Carbon::now()->translatedFormat('d F Y') }}</p>
                    <p style="font-weight: bold; margin-top: 5px;">Tata Usaha (Admin)</p>
                    <div style="height: 60px;"></div>
                    <p style="font-weight: bold; text-decoration: underline;">(..........................................)</p>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>
